# -*- coding: utf-8 -*-
#!/opt/app/python/scripts/voiceassistant/vbcsvoiceassistant/bin/python
#pip install googletrans==4.0.0-rc1
#pip install dialogflow
#pip install flask
#pip install Flask-BasicAuth
#pip install azure-cognitiveservices-speech
#pip install gTTS

from flask import Flask, request, json, Response, jsonify, make_response,send_file
import dialogflow
import uuid
from google.oauth2.service_account import Credentials
from google.api_core.exceptions import InvalidArgument
from googletrans import Translator
from flask_basicauth import BasicAuth
import traceback
from azure.cognitiveservices.speech import AudioDataStream, SpeechConfig, SpeechSynthesizer
from azure.cognitiveservices.speech.audio import AudioOutputConfig
from datetime import date
import string
import random
import os
from gtts import gTTS


app = Flask(__name__, static_folder='static')

app.config['BASIC_AUTH_USERNAME'] = 'bcstech'
app.config['BASIC_AUTH_PASSWORD'] = '***Encrypted password here***'

basic_auth = BasicAuth(app)

PROJECT_FOLDER= '/opt/app/python/scripts/voiceassistant/static/'
DIALOGFLOW_PROJECT_ID = 'voiceassistant-298918'
DIALOGFLOW_LANGUAGE_CODE = 'en-US'
GOOGLE_APPLICATION_CREDENTIALS = 'credentials.json'

credentials = Credentials.from_service_account_file(GOOGLE_APPLICATION_CREDENTIALS)
from assistant import Assistant
from audioutil import AudioUtil


@app.route("/api", methods=["POST"])
# @basic_auth.required
def perform_dialogflow():
	assistantObj=Assistant()
	return assistantObj.perform_dialogflow(request)

@app.route("/gen_audio", methods=["POST"])
# @basic_auth.required
def gen_audio():
	assistantObj=AudioUtil()
	return assistantObj.gen_audio_api(request)


@app.route("/mp3/<path>", methods=["GET"])
def getMP3(path):
	if os.path.exists(PROJECT_FOLDER+path+".wav"):
		 return send_file(PROJECT_FOLDER+path+".wav",as_attachment=True)
	elif os.path.exists(PROJECT_FOLDER+path+".mp3"):
		return send_file(PROJECT_FOLDER+path+".mp3",as_attachment=True)


@app.route('/webhook', methods=['GET','POST'])
@basic_auth.required
def webhook():
	try:
		param_list = {}
		req = request.get_json(silent=True, force=True)
		query = req.get('queryResult').get('queryText')
		parameters = req.get('queryResult').get('parameters')
		action = req.get('queryResult').get("intent").get("displayName")

		if "fulfillmentText" in req.get('queryResult'):
			fulfillmentText = req.get('queryResult').get('fulfillmentText')
			for key, value in parameters.items():
				param_list[key]=value
		# result_text = param_lister(query,  action, param_list)
		return make_response(jsonify({'fulfillmentText': result_text}),200)
	except Exception as e:
		return make_response(jsonify({'fulfillmentText': result_text}))



def send_response(action, resultText, resultSpeech):
	r = make_response(jsonify({'action':action, 'resultText':resultText, 'resultSpeech':resultSpeech}))
	r.headers['Content-Type'] = 'application/json'
	return r

if __name__ == "__main__":	
	app.run(host="bcstech.in",port=7500, debug = True,ssl_context=('/etc/letsencrypt/live/bcstech.in/fullchain.pem', '/etc/letsencrypt/live/bcstech.in/privkey.pem'))