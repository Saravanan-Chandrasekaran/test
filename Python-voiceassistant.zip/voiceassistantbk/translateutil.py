# -*- coding: utf-8 -*-
#!/opt/app/python/scripts/voiceassistant/vbcsvoiceassistant/bin/python

from googletrans import Translator

from flask import Flask, json

class TranslateUtil:
		
	def translateLanguage(self, input, target_lang):
		try:
			translator = Translator()
			jdata = json.loads(open ('langcodes.json').read())
			lang_output= target_lang.lower()
			if " " in target_lang.lower():
				lang_output= target_lang.lower().split(" ")[0]
			print("came above if")
			print(lang_output)
			print(input)
			for lang in jdata:
				if lang_output.lower() in lang['name'].lower():
					print("came to if condition")
					print(lang_output)
					print(input)
					translations = translator.translate(input, lang['code'])
					return translations.text
			return ""
		except Exception as e:
			import traceback
			print(traceback.format_exc())
			print(str(e))
			return ""