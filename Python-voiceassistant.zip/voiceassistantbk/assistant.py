# -*- coding: utf-8 -*-
#!/opt/app/python/scripts/voiceassistant/vbcsvoiceassistant/bin/python

from flask import Flask, request, json, Response, jsonify, make_response,send_file
import dialogflow
import uuid
from google.oauth2.service_account import Credentials
from google.api_core.exceptions import InvalidArgument
import traceback

from translateutil import TranslateUtil
from audioutil import AudioUtil
PROJECT_FOLDER= '/opt/app/python/scripts/voiceassistant/static/'
DIALOGFLOW_PROJECT_ID = 'voiceassistant-298918'
DIALOGFLOW_LANGUAGE_CODE = 'en-US'
GOOGLE_APPLICATION_CREDENTIALS = 'credentials.json'

credentials = Credentials.from_service_account_file(GOOGLE_APPLICATION_CREDENTIALS)

class Assistant:
	def perform_dialogflow(self, request):
		if request.method == "POST":
			try:
				TranslateUtilObj = TranslateUtil()
				AudioUtilObj = AudioUtil()
				fulfillmentText, audioID = "", ""
				query =	 request.form['query']
				source_language = request.form['source_language']
				translate_language= request.form['translate_language']
				is_translate = request.form['is_translate']
				gender = request.form['gender']
				print(gender)
				print(is_translate)
				print(query)
				print(source_language)
				if is_translate == "no":
					if "english" not in source_language.lower():
						query = TranslateUtilObj.translateLanguage(query,"english") # translated to english	
					print("Translated Query")
					print(query)
					if query:
						SESSION_ID = uuid.uuid4()
						session_client = dialogflow.SessionsClient(credentials =credentials)
						session = session_client.session_path(DIALOGFLOW_PROJECT_ID, SESSION_ID)
						text_input = dialogflow.types.TextInput(text=query, language_code=DIALOGFLOW_LANGUAGE_CODE)
						query_input = dialogflow.types.QueryInput(text=text_input)
						try:
							response = session_client.detect_intent(session=session, query_input=query_input)
						except InvalidArgument:
							raise
						action = response.query_result.intent.display_name
						
						print("fulfillment_text")
						print(response.query_result.fulfillment_text)
						fulfillmentText = TranslateUtilObj.translateLanguage(response.query_result.fulfillment_text,translate_language) # translated to english
						return self.intentDetection(action, fulfillmentText,translate_language,gender)
				else:
					fulfillmentText = TranslateUtilObj.translateLanguage(query,translate_language) # translated to english
					print("fulfillmentText")
					print(fulfillmentText)
					print("translate_language")
					print(translate_language)
					audioID=  AudioUtilObj.tts_language(fulfillmentText, translate_language,gender)
				
				return self.send_response(action="general", resultText=fulfillmentText, resultSpeech=audioID)
			except Exception as e:
				print(traceback.format_exc())
				print(str(e))
				return self.send_response(action="failed", resultText="failed", resultSpeech="failed")


	def webhook(self, request):
		try:
			param_list = {}
			req = request.get_json(silent=True, force=True)
			query = req.get('queryResult').get('queryText')
			parameters = req.get('queryResult').get('parameters')
			action = req.get('queryResult').get("intent").get("displayName")

			if "fulfillmentText" in req.get('queryResult'):
				fulfillmentText = req.get('queryResult').get('fulfillmentText')
				for key, value in parameters.items():
					param_list[key]=value
			result_text = self.param_lister(query,	action, param_list)
			return make_response(jsonify({'fulfillmentText': result_text}),200)
		except Exception as e:
			return make_response(jsonify({'fulfillmentText': result_text}))
		
		
		
	def intentDetection(self, intent, fulfillmentText,translate_language,gender):
		AudioUtilObj = AudioUtil()
		audioID =  AudioUtilObj.tts_language(fulfillmentText, translate_language,gender)
		return self.send_response(action="general", resultText=fulfillmentText, resultSpeech=audioID)
		
		

	def param_lister(self, query, action, param_list):
		if action == "news":
			text = "Sample news."
			return text
		if action == "device":
			text = "your mobile battery percentage is {}. I will let you know when my battery percentage is very low."
			return text


	def send_response(self, action, resultText, resultSpeech):
		r = make_response(jsonify({'action':action, 'resultText':resultText, 'resultSpeech':resultSpeech}))
		r.headers['Content-Type'] = 'application/json'
		return r