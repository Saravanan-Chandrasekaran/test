# -*- coding: utf-8 -*-
#!/opt/app/python/scripts/voiceassistant/vbcsvoiceassistant/bin/python
from flask import Flask, request, json, Response, jsonify, make_response,send_file
from azure.cognitiveservices.speech import AudioDataStream, SpeechConfig, SpeechSynthesizer
from azure.cognitiveservices.speech.audio import AudioOutputConfig
from datetime import date
import string
import random
import os
import traceback
# from gtts import gTTS
from google.cloud import texttospeech
from translateutil import TranslateUtil

PROJECT_FOLDER= '/opt/app/python/scripts/voiceassistant/static/'
class AudioUtil:
	def gen_audio_api(self, request):
		if request.method == "POST":
			try:
				fulfillmentText, audioID = "", ""
				query =	 request.form['query']
				translate_language= request.form['translate_language']
				if query and translate_language:
					TranslateUtilObj = TranslateUtil()
					fulfillmentText = TranslateUtilObj.translateLanguage(query,translate_language) # translated to english
					audioID=  self.tts_language(fulfillmentText, translate_language)
					return self.send_response(action=fulfillmentText, resultText=fulfillmentText, resultSpeech=audioID)
				else: 
					return self.send_response(action="failed", resultText="failed", resultSpeech="failed")
			except Exception as e:
				print(traceback.format_exc())
				print(str(e))
				return self.send_response(action="failed", resultText="failed", resultSpeech="failed")
			
	def getMP3(self,  path):
		if os.path.exists(PROJECT_FOLDER+path+".mp3"):
			return send_file(PROJECT_FOLDER+path+".mp3",as_attachment=True)
		
	
	def translateLanguage(self, input, target_lang):
		try:
			translator = Translator()
			jdata = json.loads(open ('langcodes.json').read())
			for lang in jdata:
				if lang['name'].lower() == target_lang.lower():
					translations = translator.translate(input, lang['code'])
					return translations.text
			return ""
		except Exception as e:
			print(str(e))
			return ""
			
	def tts_language(self, data, language,gender, path =False):
		try:
			print("inside tts language")
			print(data)
			print(language)
			language_code = ""
			jdata = json.loads(open ('google_tts.json').read())
			for lang in jdata:
				if lang['language'].lower() == language.lower():
					language_code = lang['lang_code']
			
			print(language_code)
			article_id=self.id_generator()
			directory = PROJECT_FOLDER
			if path:
				filepath = directory+article_id+"/"+article_id
			else:
				filepath = directory+article_id
				
			if language_code:
				
				tts = self.google_tts(data, gender, language_code,filepath+".mp3")
				# tts = gTTS(data, language_code)
				# tts.save(filepath+".mp3") 
				print(filepath+".mp3")
				return article_id
			return article_id
		except Exception as e:
			import traceback
			print(traceback.format_exc())
			
	
	def google_tts(self, data, gender, language,path):
		client = texttospeech.TextToSpeechClient()
		synthesis_input = texttospeech.SynthesisInput(text=data)
		if gender.lower() =="female":
			voice = texttospeech.VoiceSelectionParams(
				language_code=language, ssml_gender=texttospeech.SsmlVoiceGender.FEMALE
			)	
		else:
			voice = texttospeech.VoiceSelectionParams(
				language_code=language, ssml_gender=texttospeech.SsmlVoiceGender.MALE
			)

		audio_config = texttospeech.AudioConfig(
			audio_encoding=texttospeech.AudioEncoding.MP3
		)
		response = client.synthesize_speech(
			input=synthesis_input, voice=voice, audio_config=audio_config
		)
		with open(path, "wb") as out:
			# Write the response to the output file.
			out.write(response.audio_content)
			print('Audio content written to file "output.mp3"')
			return True
		return False
	def id_generator(self, size=6, chars=string.ascii_uppercase + string.digits):
		return ''.join(random.choice(chars) for _ in range(size))


	def send_response(self, action, resultText, resultSpeech):
		r = make_response(jsonify({'action':action, 'resultText':resultText, 'resultSpeech':resultSpeech}))
		r.headers['Content-Type'] = 'application/json'
		return r